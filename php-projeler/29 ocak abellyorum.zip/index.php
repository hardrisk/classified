<?php

mysql_connect("host", "kullaniciadi", "parola");
mysql_select_db("veritabaniadi");

$find_comments = mysql_query("SELECT * FROM entariler order by entrynumara asc");
while($row = mysql_fetch_assoc($find_comments))
{
$yazan = $row['yazan'];
$zaman = $row['elma'];
$entari_icerik = $row['armut'];
$entarino = $row['entrynumara'];

echo "<strong style='margin-left:10px;margin-top:30px'>$entarino</strong>.)<br><strong style='font-size:8px;margin-left:-10px;margin-top:30px'>.</strong>";
echo "<center><div style='background-color:darkgray;color:black;width:98%'><label style='position:relative;top:8px;font-size:16px;'>";
echo nl2br($zaman);
echo "</label><br><span style='font-size:14px;color:red;margin-left:87%;'>$yazan</span><br><span style='font-size:12px;color:darkblue;margin-left:87%;'>$entari_icerik</span></div><p></center>";
}
if(isset($_GET['error']))
{
echo "<center><p>yazdiklariniz kaydolmadi. karakter limitine takildiniz.</p>";
}
?>

<html>
<head>
<meta charset="UTF-8">
<base targ="_blank">
<style>
/* unvisited link */
a:link {
color: blue;
text-decoration: none;
}

/* visited link */
a:visited {
color: purple;
}

/* mouse over link */
a:hover {
color: blue;
text-decoration: underline;
}

/* selected link */
a:active {
color: red;
text-decoration: none;
}
</style>

<style>
#div1 {
color:red;
width:20%;
padding:20px 0;
text-align:center;
background-color:black;
margin-top:20px;
display:none;
}
</style>
</head>

<body bgcolor="gray">

<!--- burasi sol �stteki saat i�in --->
<div id="date-time" onclick="location.href='giris.html'" style='font-family:"Lucida Console";font-size:11px;line-height:12px;cursor:default;z-index:1;background-color:#ccc;text-align:center;position:fixed;top:0;left:0;height:24px;width:74px;border:4px solid #777'></div>
<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
<script>
function updatingClock(selector, type) {
    function currentDate() {
        var currentDate = new Date;
        var Day = currentDate.getDate();
        if (Day < 10) {
            Day = '0' + Day;
        } //end if
        var Month = currentDate.getMonth() + 1;
        if (Month < 10) {
            Month = '0' + Month;
        } //end if
        var Year = currentDate.getFullYear();
        var fullDate = Day + '.' + Month + '.' + Year;
        return fullDate;
    } //end current date function

    function currentTime() {
        var currentTime = new Date;
        var Seconds = currentTime.getSeconds();
        if (Seconds < 10) {
            Seconds = '0' + Seconds;
        }
        var Minutes = currentTime.getMinutes();
        if (Minutes < 10) {
            Minutes = '0' + Minutes;
        }
        var Hour = currentTime.getHours();
        if (Hour < 10) {
            Hour = '0' + Hour;
        } //end if
        var Time = Hour + ':' + Minutes + ':' + Seconds;
        return Time;
    } // end current time function


    function updateOutput() {
        var output;
        if (type == 'time') {
            output = currentTime();
            if ($(selector).text() != output) {
                $(selector).text(output);
            } //end if
        } //end if
        if (type == 'date') {
            output = currentDate();
            if ($(selector).text() != output) {
                $(selector).text(output);
            } //end if
        } //end if
        if (type == 'both') {
            output = ' ' + currentTime() + ' ' + currentDate();
            if ($(selector).text() != output) {
                $(selector).text(output);
            } //end if
        } //end if
    }//end update output function
    updateOutput();
    window.setInterval(function() {
        updateOutput();
    }, 1000); //run update every 1 second
} // end updating clock function
updatingClock('#date-time', 'both');
</script>
<!--- burasi sol �stteki saat i�in --->

<!--- burasi ikinci sol �stteki saat i�in --->
<div id="date-time2" onclick="location.href='giris.html'" style='font-family:"Lucida Console";font-size:8px;line-height:10px;cursor:default;z-index:1;background-color:#ccc;text-align:center;position:fixed;top:65;left:0;height:20px;width:56px;border:4px solid #777'></div>
<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
<script>
function updatingClock(selector, type) {
    function currentDate() {
        var currentDate = new Date;
        var Day = currentDate.getDate();
        if (Day < 10) {
            Day = '0' + Day;
        } //end if
        var Month = currentDate.getMonth() + 1;
        if (Month < 10) {
            Month = '0' + Month;
        } //end if
        var Year = currentDate.getFullYear();
        var fullDate = Day + '.' + Month + '.' + Year;
        return fullDate;
    } //end current date function

    function currentTime() {
        var currentTime = new Date;
        var Seconds = currentTime.getSeconds();
        if (Seconds < 10) {
            Seconds = '0' + Seconds;
        }
        var Minutes = currentTime.getMinutes();
        if (Minutes < 10) {
            Minutes = '0' + Minutes;
        }
        var Hour = currentTime.getHours();
        if (Hour < 10) {
            Hour = '0' + Hour;
        } //end if
        var Time = Hour + ':' + Minutes + ':' + Seconds;
        return Time;
    } // end current time function


    function updateOutput() {
        var output;
        if (type == 'time') {
            output = currentTime();
            if ($(selector).text() != output) {
                $(selector).text(output);
            } //end if
        } //end if
        if (type == 'date') {
            output = currentDate();
            if ($(selector).text() != output) {
                $(selector).text(output);
            } //end if
        } //end if
        if (type == 'both') {
            output = ' ' + currentTime() + ' ' + currentDate();
            if ($(selector).text() != output) {
                $(selector).text(output);
            } //end if
        } //end if
    }//end update output function
    updateOutput();
    window.setInterval(function() {
        updateOutput();
    }, 1000); //run update every 1 second
} // end updating clock function
updatingClock('#date-time2', 'both');
</script>
<!--- burasi ikinci sol �stteki saat i�in --->

<center>

<h2>YORUM YAP</h2>
<p>alter table karpuz AUTO_INCREMENT=1</p><button onclick="asd()">saat</button>
<p style='font-size:11px'>giris yapma ve mesaj silme sistemi burada yok*</p>nl2br<br>
<p>latin5_turkish_ci secilir her zaman</p>
<a href="vtyedekle.php">vtyedekle.php</a><br>
<form action="yorum.php" method="POST">
<div id="div1">zaman: <input type="text" readonly size="14" name="elma" required id="tarih"><br></div>yazan:<br>
<input type="text" style="text-align:center" value="Vice" size="10" name="yazan"><br>mesajiniz:<br>
<textarea autofocus style="background-color:#ccc;border: 2px solid;outline:none;color:black;text-align:center" placeholder=" " name="armut" cols="100" rows="8"></textarea><br>
<input type="submit" value="yolla">

</center>
</body>

<script>
var timer = setInterval( getDate, 1000);
function getDate(){
var todaydate = new Date();
var aa = todaydate.getHours();
var bb = todaydate.getMinutes();
var cc = todaydate.getSeconds();
var dd = todaydate.getDate();
var ee = todaydate.getMonth() + 1;
var ff = todaydate.getFullYear();

if (aa < 10) {
  aa = '0' + aa;
}
if (bb < 10) {
  bb = '0' + bb;
}
if (cc < 10) {
  cc = '0' + cc;
}
if (dd < 10) {
  dd = '0' + dd;
}
if (ee < 10) {
  ee = '0' + ee;
}

var datestring = dd + "." + ee + "." + ff + " " + aa + ":" + bb + ":" + cc;
document.getElementById("tarih").value = datestring; //don't need ()
}
document.getElementById("tarih").onload = getDate();
</script>

<script>
function asd() {
    var x = document.getElementById("div1");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
</script>
</html>