<?php

$pre_file_name = $_POST['name'];

$ext = "";

$file_name = $pre_file_name.$ext;

fopen($file_name,'w');

?>

<html><title>dosya olu&#351;tur</title>
<body bgcolor="gray">
<center>
<form action="edit_file.php" method="POST">
Metin:<br><textarea autofocus name="edit" cols="120" rows="30"></textarea><p>
<input type="hidden" name="file_name" value="<?php echo $file_name; ?>">
<input type="submit" value="Kaydet">
</form>
</html>