<?php

$edit = $_POST['edit'];

$file_name = $_POST['file_name'];

$file = fopen($file_name, 'w');

fwrite($file,$edit);

fclose($file);

echo "<title>editle</title><body bgcolor='gray'><center><br><br><br><br><br><br><br><span style='font-size:38pt'>ba&#351;ar&#305;yla kaydedildi!! &#10003;</span><br><a href='index.php'>TAMAM</a>";

?>

<script type="text/javascript">
    window.setTimeout(function() {
        window.location.href='index.php';
    }, 650);
</script>