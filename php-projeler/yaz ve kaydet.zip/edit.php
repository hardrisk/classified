<?php

$file_name = $_GET['name'];

$file_read = fopen($file_name,"r");
$contents = fread($file_read, filesize($file_name));
fclose($file_read);

?>

<html><title>dosyayi editle</title>
<body bgcolor="gray">
<center>
<form action="edit_file.php" method="POST">
<textarea autofocus style="outline:none" name="edit" cols="120" rows="30"><?php echo $contents; ?></textarea><p>
<input type="hidden" name="file_name" value="<?php echo $file_name; ?>">
<input type="submit" value="Save">
</form>
</center>
</body>
</html>