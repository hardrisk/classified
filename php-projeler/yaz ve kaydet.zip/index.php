<html>
<head>
<meta charset="UTF-8">
<title>YAZ VE KAYDET</title>
</head>
<body bgcolor="gray">
<center>
<form action="create_file.php" method="POST">
File Name: <input autofocus type="text" name="name" value=".html"><br>uzanti degistirilebilir (.html, .php, .css, .bat, .txt vb.)<p>
<input type="submit" value="Create File">
</form>
<p>
<p style="font-size:25px">Files:</p>
<?php

$full_path = ".";

$dir = @opendir($full_path) or die ("Unable to open directory");

while($file = readdir($dir))
{
	if($file == "." || $file == ".." || $file == "index.php" || $file == "create_file.php" || $file == "edit_file.php" || $file == "edit.php" || $file == "delete.php")
	
	continue;
	
	echo "<a href='$file'>$file</a> ... <a href='edit.php?name=$file'>Duzenle</a> ... <a href='delete.php?name=$file'>Sil</a><br>";
}

closedir($dir);
?>

</center>
</body>
</html>