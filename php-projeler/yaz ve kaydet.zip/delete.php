<?php

$file = $_GET['name'];

unlink($file);

echo "<html>
<body bgcolor='gray'>
<center><br><br><br><br><br><br><br><span style='font-size:38pt'>ba&#351;ar&#305;yla silindi! &#10003;</span><br><a href='index.php'>TAMAM</a>";

?>

<script type="text/javascript">
    window.setTimeout(function() {
        window.location.href='index.php';
    }, 850);
</script>