<?php include('sorgular.php') ?>
<html>
<head>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/reset.css">
<title>Vice Sözlük 2</title>
<style>

</style>
</head> 
<body>
<div class="container">