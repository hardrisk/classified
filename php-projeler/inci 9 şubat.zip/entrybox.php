<form action="islem.php" method="POST"><center><input readonly type="text" id="tarih" name="zaman"></center>
<ul class="buttons">
<li><button class="buttonstyle" style="float: right;">*</button></li>
<li><button class="buttonstyle" style="float: right;">-!sl-</button></li>
<li><button class="buttonstyle" style="float: right;">' '</button></li>
<li><button class="buttonstyle" style="float: right;">(bkz:</button></li>
</ul>
<center>
<textarea autofocus style="outline:none;border:2px solid black" rows="5" name="entari_mesaj" class="asd12"></textarea>
<ul>
<li><button class="buttonstyle" type="submit" name="ekle" value="kaydet" style="float:left;margin-right:10px">yolla panpa</button></li>
<li><button disabled class="buttonstyle" name="asdxd" style="float:left">caps</button></li> <!--- disabled yapılabilir --->
</ul>
</form>
</div><br><br><br><br><br><br>
</body>
<script>
var timer = setInterval( getDate, 1000);
function getDate(){
var todaydate = new Date();
var aa = todaydate.getHours();
var bb = todaydate.getMinutes();
var cc = todaydate.getSeconds();
var dd = todaydate.getDate();
var ee = todaydate.getMonth() + 1;
var ff = todaydate.getFullYear();

if (aa < 10) {
  aa = '0' + aa;
}
if (bb < 10) {
  bb = '0' + bb;
}
if (cc < 10) {
  cc = '0' + cc;
}
if (dd < 10) {
  dd = '0' + dd;
}
if (ee < 10) {
  ee = '0' + ee;
}

var datestring = dd + "." + ee + "." + ff + " " + aa + ":" + bb + ":" + cc;
document.getElementById("tarih").value = datestring; //don't need ()
}
document.getElementById("tarih").onload = getDate();
</script>
</html>