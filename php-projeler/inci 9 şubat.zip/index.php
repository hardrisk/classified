<?php include('header.php');
$baslik_cek=mysql_fetch_array($baslik_sorgu)
?>
<div class="baslik_style"><?php echo $baslik_cek['baslik']; ?></div>

<?php while ($entari_cek=mysql_fetch_array($entari_sorgu)) { ?>
<font style="color:#000;font-weight:bold"><?php echo $entari_cek["entari_id"].".)"; ?></font>
<?php
$lala = $entari_cek["entari_mesaj"];
?>
<ul class="entryshow">
<li><center><?php echo nl2br ($lala); ?></li>
</ul>

<?php } ?>

<?php include('entrybox.php');?>