<?php
include('baglan.php');
$entari_mesaj=$_POST["entari_mesaj"];

$entari = str_replace("'", "\'", $entari_mesaj); //kesme işaretinin düzgün çıkması için
$entari = str_replace("bok", "b*k", $entari_mesaj); //sansür
$entari = str_replace("<br>", "", $entari_mesaj); //br'lerin yok edilmesi

/* BOŞ ENTRY GİRMEYİ ENGELLEME KODU BAŞLANGICI */
$entari = trim($entari);

if(empty($entari)){
header("location: index.php?bosentari=1");
return false; // bu satır engelliyor boş metin girmeyi
}
/* BOŞ ENTRY GİRMEYİ ENGELLEME KODU SONU */

if (isset($_POST['ekle']))
{
$ekle=mysql_query("insert into entariler (entari_mesaj) VALUES ('$entari')");
if (mysql_affected_rows())
{
header('Location: index.php?durum=yes');
}
else
{
header('Location: index.php?durum=no');
}
}

?>