<?php

mysql_connect("host", "kullaniciadi", "parola");
mysql_select_db("veritabaniadi");

$armut = $_POST["armut"];
$elma = $_POST["elma"];
$yazan = $_POST["yazan"];

$comment_length = strlen($comment);

if($comment_length > 200)
{
	header("location: index.php?error=1");
}
else
{
	mysql_query("INSERT INTO entariler VALUES('.','$armut','$elma','$yazan')");
	header("location: index.php");
}
?>