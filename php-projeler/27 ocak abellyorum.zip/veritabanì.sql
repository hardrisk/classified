-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Anamakine: sql210.byetcluster.com
-- Üretim Zamanı: 27 Oca 2019, 01:55:58
-- Sunucu sürümü: 5.6.41-84.1
-- PHP Sürümü: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `ezyro_21763626_comments`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `basliklar`
--

CREATE TABLE IF NOT EXISTS `basliklar` (
  `baslik` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `basliklar`
--

INSERT INTO `basliklar` (`baslik`) VALUES
('şarkılar'),
('videolar'),
('html işleri'),
('javascript işleri'),
('chrome eklentileri'),
('ekşi anket');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `entariler`
--

CREATE TABLE IF NOT EXISTS `entariler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elma` varchar(1000) COLLATE utf32_turkish_ci NOT NULL,
  `armut` varchar(1000) COLLATE utf32_turkish_ci NOT NULL,
  `yazan` varchar(1000) COLLATE utf32_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf32 COLLATE=utf32_turkish_ci AUTO_INCREMENT=56 ;

--
-- Tablo döküm verisi `entariler`
--

INSERT INTO `entariler` (`id`, `elma`, `armut`, `yazan`) VALUES
(2, 'poooooooooo', '26.01.2019 05:19:52', ''),
(18, 'Ã§Ã¶pÃ§Ã¼ Ã§iÅ? Ã¶Ä?Ã¼ttÃ¼ \r\n', '26.01.2019 08:12:24', ''),
(7, 'Ã§Ã¶p', '26.01.2019 05:30:19', ''),
(8, 'asd\r\n123', '26.01.2019 05:31:03', ''),
(9, 'Ã§Ã¶pÃ§Ã¼ Ã§iÅ? Ã¶Ä?Ã¼ttÃ¼', '26.01.2019 05:34:40', ''),
(10, 'Ã§Ã¶pÃ§Ã¼ Ã§iÅ? Ã¶Ä?Ã¼ttÃ¼', '26.01.2019 05:36:06', ''),
(11, 'Ã§Ã¶pÃ§Ã¼ Ã§iÅ? Ã¶Ä?Ã¼ttÃ¼ \r\n', '26.01.2019 05:50:05', ''),
(12, 'Ã§Ã¶pÃ§Ã¼ Ã§iÅ? Ã¶Ä?Ã¼ttÃ¼ \r\n', '26.01.2019 06:09:10', ''),
(13, '<p>alÄ±nacaklar:</p>\r\n\r\ntoka<br>\r\nmp3<br>\r\nkulaklÄ±k<br>\r\nbilgisayar<br>\r\nayakkabÄ±<br>\r\n', '26.01.2019 07:39:08', ''),
(14, 'span<br>\r\npre<br>\r\nfont<br>\r\nlabel<br>\r\nstrong<br>', '26.01.2019 07:44:01', ''),
(16, '<a href="https://profreehost.com/login">Client Login - ProFreeHost</a>\r\n', '26.01.2019 07:45:10', ''),
(15, 'safsdfg\r\n\r\n222', '26.01.2019 08:06:26', ''),
(19, 'Ã§Ã¶pÃ§Ã¼ Ã§iÅ? Ã¶Ä?Ã¼ttÃ¼ \r\n', '26.01.2019 08:13:58', ''),
(20, 'Ã§Ã¶pÃ§Ã¼ Ã§iÅ? Ã¶Ä?Ã¼ttÃ¼ \r\n', '26.01.2019 08:42:12', ''),
(21, 'Ã§Ã¶pÃ§Ã¼ Ã§iÅŸi Ã¶ÄŸÃ¼ttÃ¼', '26.01.2019 08:54:33', ''),
(22, 'ÄŸÃ¼iÅŸÃ§Ã¶', '26.01.2019 08:54:45', ''),
(23, 'alÄ±nacaklar:\r\n\r\ntoka\r\nmp3\r\nkulaklÄ±k\r\nbilgisayar\r\nayakkabÄ±', '26.01.2019 08:55:45', ''),
(24, 'alÄ±nacaklar:\r\n\r\ntoka\r\nmp3\r\nkulaklÄ±k\r\nbilgisayar\r\nayakkabÄ±', '26.01.2019 08:56:54', ''),
(25, 'Ã¶Ã§ÅŸiÃ¼ÄŸ', '26.01.2019 09:06:19', ''),
(26, 'ses', '26.01.2019 10:27:48', ''),
(27, '<a href="http://viceveralone.ezyro.com/inci">inci</a><br>\r\n<a href="http://viceveralone.ezyro.com/abellyorum/dnm">abellyorum/dnm</a><br>\r\n<a href="http://viceveralone.ezyro.com/abellyorum">abellyorum</a>', '26.01.2019 10:30:17', ''),
(28, 'Ã¶Ã§ÅŸiÃ¼ÄŸ', '26.01.2019 10:34:24', ''),
(29, 'Ã¶Ã§ÅŸiÃ¼ÄŸ', '26.01.2019 10:39:16', ''),
(30, 'Ã¼ÄŸiÅŸÃ§Ã¶', '26.01.2019 10:41:39', ''),
(31, '123\r\n456', '26.01.2019 10:53:15', ''),
(32, 'benim\r\nadÄ±m\r\nvice', '26.01.2019 10:56:42', ''),
(33, '<a href="https://namvideo.com/watch/video_id">namvideo.com/watch/video_id</a>', '26.01.2019 11:12:03', ''),
(34, '\r\n\r\n\r\n', '26.01.2019 11:12:35', ''),
(35, '<a href="http://www.oguzhantas.com/linux/12-hangi-linux-dagitimi.html">Hangi Linux DaÄŸÄ±tÄ±mÄ±?, Linux Kategorisi</a><br>\r\n', '26.01.2019 11:20:06', ''),
(36, 'sad', '26.01.2019 11:57:48', 'lol'),
(37, '<a href="https://www.youtube.com/watch?v=TKp1xzYbv0A">Check Yo Self - Ice Cube - GTA San Andreas Soundtrack - YouTube</a>', '26.01.2019 13:03:07', ''),
(38, '<a href="https://eksisozluk.com/yuzustu-birakilma-anilari--5915844">yÃ¼zÃ¼stÃ¼ bÄ±rakÄ±lma anÄ±larÄ± - ekÅŸi sÃ¶zlÃ¼k</a>', '26.01.2019 13:36:02', ''),
(39, '<a href="http://small.cf/">small.cf URL Shortener</a>', '26.01.2019 14:47:02', ''),
(40, '39162', '26.01.2019 15:42:31', ''),
(41, '38154', '26.01.2019 23:16:49', ''),
(42, 'www.scripthaneniz.com', '26.01.2019 23:32:25', ''),
(43, '<a href="https://www25.zippyshare.com/v/MdAY39iI/file.html">Zippyshare.com - 65.0.3325.146 dragon_setup.exe</a>', '26.01.2019 23:34:33', ''),
(44, '<a href="https://dizibox5.org/westworld-1-sezon-1-bolum/2/">Westworld 1.Sezon 1.BÃ¶lÃ¼m Ä°zle - TÃ¼rkÃ§e AltyazÄ±lÄ± Ä°zle - DiziBox - Part 2</a>', '27.01.2019 07:08:19', ''),
(45, 'Ã§Ã¶pÃ¼ÅŸ', '27.01.2019 08:50:13', 'vice'),
(53, '        $yazan = $row["yazan"];\r\n	$zaman = $row["elma"];\r\n	$entari_icerik = $row["armut"];\r\n        $entarino = $row["id"];', '27.01.2019 09:21:16', 'vice');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
