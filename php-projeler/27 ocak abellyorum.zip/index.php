<?php

mysql_connect("host", "kullaniciadi", "parola");
mysql_select_db("veritabaniadi");

$find_comments = mysql_query("SELECT * FROM entariler order by id asc");
while($row = mysql_fetch_assoc($find_comments))
{
$yazan = $row['yazan'];
$zaman = $row['elma'];
$entari_icerik = $row['armut'];
$entarino = $row['id'];


echo "<strong style='margin-left:10px;margin-top:30px'>$entarino</strong>.)<br><strong style='font-size:8px;margin-left:-10px;margin-top:30px'>.</strong>";
echo "<center><div style='background-color:darkgray;color:black;width:98%'><label style='position:relative;top:8px;font-size:16px;'>";
echo nl2br($zaman);
echo "</label><br><span style='font-size:14px;color:red;margin-left:87%;'>$yazan</span><br><span style='font-size:12px;color:darkblue;margin-left:87%;'>$entari_icerik</span></div><p></center>";
}
if(isset($_GET['error']))
{
echo "<p>200 karakter limitine takildin";
}
?>

<html>
<head>
<meta charset="UTF-8">
<style>
#div1 {
color:red;
width:20%;
padding:20px 0;
text-align:center;
background-color:black;
margin-top:20px;
display:none;
}
</style>
</head>

<body bgcolor="gray">
<center>

<h2>YORUM YAP</h2>
<p>alter table karpuz AUTO_INCREMENT=1</p><button onclick="asd()">saat</button>
<p style='font-size:11px'>giris yapma ve mesaj silme sistemi burada yok*</p>nl2br<br>
<p>latin5_turkish_ci secilir her zaman</p>
<form action="yorum.php" method="POST">
<div id="div1">zaman: <input type="text" readonly size="14" name="elma" required id="tarih"><br></div>yazan:<br>
<input type="text" value="vice" size="20" name="yazan"><br>mesajiniz:<br>
<textarea autofocus placeholder="yaz..." name="armut" cols="120" rows="10"></textarea><br>
<input type="submit" value="yolla">

</center>
</body>

<script>
var timer = setInterval( getDate, 1000);
function getDate(){
var todaydate = new Date();
var aa = todaydate.getHours();
var bb = todaydate.getMinutes();
var cc = todaydate.getSeconds();
var dd = todaydate.getDate();
var ee = todaydate.getMonth() + 1;
var ff = todaydate.getFullYear();

if (aa < 10) {
  aa = '0' + aa;
}
if (bb < 10) {
  bb = '0' + bb;
}
if (cc < 10) {
  cc = '0' + cc;
}
if (dd < 10) {
  dd = '0' + dd;
}
if (ee < 10) {
  ee = '0' + ee;
}

var datestring = dd + "." + ee + "." + ff + " " + aa + ":" + bb + ":" + cc;
document.getElementById("tarih").value = datestring; //don't need ()
}
document.getElementById("tarih").onload = getDate();
</script>

<script>
function asd() {
    var x = document.getElementById("div1");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
</script>
</html>