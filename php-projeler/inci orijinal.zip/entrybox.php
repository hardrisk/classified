<form action="islem.php" method="POST">
<ul class="buttons">
<li><button class="buttonstyle" style="float: right;">*</button></li>
<li><button class="buttonstyle" style="float: right;">-!sl-</button></li>
<li><button class="buttonstyle" style="float: right;">' '</button></li>
<li><button class="buttonstyle" style="float: right;">(bkz:</button></li>
</ul>
<textarea autofocus name="entari_mesaj" class="textaira" placeholder="Entry Girin"></textarea>
<ul>
<li><button class="buttonstyle" type="submit" name="ekle" value="kaydet" style="float: left; margin-right: 10px">yolla panpa</button></li>
<li><button class="buttonstyle"  style="float: left;">caps</button></li>
</ul>
</form>
</div>
</body>
</html>