<?php include('sorgular.php') ?>
<html>
<head>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/reset.css">
</head> 
<body>
<div class="container">
		
