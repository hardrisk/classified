<?php include("baglan.php") ?>
<?php $entari_sorgu=mysql_query("select * from entariler"); ?>
<?php $baslik_sorgu=mysql_query("select * from baslik"); ?>